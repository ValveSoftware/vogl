// SubModule2.h - Master header with same name as directory.
#include "SubModule2/Header3.h"
#include "SubModule2/Header4.h"
