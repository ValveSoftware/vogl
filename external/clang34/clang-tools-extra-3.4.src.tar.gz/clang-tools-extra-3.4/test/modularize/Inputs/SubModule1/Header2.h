// Header2.h - Empty.
