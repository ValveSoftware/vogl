#ifndef _HEADERGUARDSUBSUB_H_
#define _HEADERGUARDSUBSUB_H_

#define SOMETHING 1

// Nest include.  Header guard should not confuse modularize.
#include "HeaderGuard.h"

#endif // _HEADERGUARDSUBSUB_H_
