// Same decl as in DuplicateHeader2.h.
typedef int TypeInt;
