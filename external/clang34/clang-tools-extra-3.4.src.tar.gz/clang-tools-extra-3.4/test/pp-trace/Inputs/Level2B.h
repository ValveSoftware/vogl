#define MACRO_2B 1
