============================
C++11 Migrator User's Manual
============================

This tool has been renamed :doc:`clang-modernize <clang-modernize>`.
